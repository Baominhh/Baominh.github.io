<body>   
    <nav class="ta-navbar navbar navbar-expand-lg sticky-top navbar-white bg-white shadow-sm">
        <div class="container-fluid ta-container">
            <div class="d-flex align-items-center">
                <button type="button" aria-label="Toggle navigation" class="navbar-toggler">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <a href="/" class="navbar-brand fw-bold d-flex align-items-center nuxt-link-active">
                    <img height="27" alt="trumacc logo" src="https://napthevip.vn/storage/images/16/643ea72de6a38_ntvlogo.png">
                </a>
                <ul class="navbar-nav dropdown-profile">
                                        <li class="nav-item dropdown bg-light rounded">
                        <a href="#" role="button" data-bs-toggle="dropdown" data-bs-display="static"
                            aria-expanded="false" class="nav-link dropdown-toggle d-flex align-items-center">
                            <img alt="" src="https://cdn.vani.tv/images/346888157_283719940760868_1596733439219575755_n.jpg"
                                class="img-navbar rounded-circle shadow-sm me-1">
                            <span class="px-0 px-sm-1 lh-0 fs-13">
                                <span class="text-muted d-none d-sm-inline">Vani -
                                </span>
                                <span class="fw-bold text-teal px-1 px-sm-0">
                                    <span data-v-0abbdf5a="">Admin</span></span>
                            </span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a href="/thong-tin" class="dropdown-item">
                                    <i class="fal fa-user-circle"></i>
                                    <span>Thông tin</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                </ul>


            </div>
            <div class="collapse navbar-collapse my-2 mt-lg-0 mb-1 mb-lg-0">
                <ul class="navbar-nav navbar-main me-auto">
                    <li class="nav-item">
                        <a href="/" class="nav-link"><i class="fal text-dark fa-home"></i> Cá nhân
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="/banking" class="nav-link" aria-current="page"><i class="fal text-dark fa-wallet"></i>
                            Thanh toán
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>