<footer class="bg-dark">
    <div class="ta-container pt-4">
        <div class="row">
            <div class="col-xl-4">
                <div class="mb-3">
                    <p class="text-white ta-content-fit fs-13 mb-0">
                        <strong>Vani.realest</strong>
                    </p>
                </div>
            </div>
            <div class="col-xl col-sm-6">
                <div class="mb-3">
                </div>
            </div>
            <div class="col-xl col-sm-6">
                
            </div>
            <div class="col-xl col-sm-6">
                <div class="mb-3">
                    <h4 class="ta-footer-title ta-footer-fit">
                        <strong>Hỗ trợ</strong>
                    </h4>
                    <div>
                        <a href="mailto:admin@gmail.com" class="ta-footer-link ta-content-fit">
                            <i class="fa fa-envelope"></i>
                            vanirealest@gmail.com </a>
                        <a href="tel:+84123456789" class="ta-footer-link ta-content-fit">
                            <i class="fa fa-phone-alt"></i>
                            0935974907 </a>
                        <a href="" target="_blank" class="ta-footer-link ta-content-fit">
                            <i class="fab fa-facebook-square"></i>
                            Fanpage
                        </a>
                        <a href="" target="_blank" class="ta-footer-link ta-content-fit">
                            <i class="fa fa-user-friends"></i>
                            Nhóm cộng đồng
                        </a>
                        <a href="" target="_blank" class="ta-footer-link ta-content-fit">
                            <i class="fab fa-facebook-messenger"></i>
                            Messenger
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="ta-container border-top border-gray">
        <div class="text-white text-center text-xl-start py-3 fs-14"><strong>VANI</strong> - All rights
            reserved.
        </div>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="assets/js/app.js"></script>

<script>
// Pusher.logToConsole = true;
// var pusher = new Pusher('846dc9bc93824aec119b', {
//     cluster: 'ap1'
// });

// var channel = pusher.subscribe('busy-summit-680');
// channel.bind('notify', function(data) {
//     noti(data.status, data.message);
//     if (data.href) {
//         var load = setInterval(() => {
//             window.location.href = data.href;
//             clearInterval(load);
//         }, 700)
//     }
// });
</script>
</body>

</html>